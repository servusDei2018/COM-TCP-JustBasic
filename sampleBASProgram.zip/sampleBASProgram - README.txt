This is the readme for the ZIP file
"sampleBASProgram.zip".

This includes a sample BAS program
to interface with COM10.

Note that for this to work, you have to
have installed COM0COM (as described in
its ZIP file's readme) and have ran
the TCP/COM relay (contained in the 
"tcp-serial-server and support files.zip"
according to the README there).

Running this is the LAST step in the process.