-INSTALLING COM0COM

Run either installer application:
	Setup_com0com_v3.0.0.0_W7_x64_signed.exe (For 64 bit PCs)
	Setup_com0com_v3.0.0.0_W7_x86_signed.exe (For 32 bit PCs)

If necessary, download one from https://sourceforge.net/projects/com0com/

When prompted to "Install this device software,"
click "Install." You'll have to do this twice (or perhaps more times,
if you're using a newer installer.)

When it says "Installation Complete," hit "Next >"

Setup should now finish.


-CONFIGURING COM0COM

Now, open the start menu (Windows Symbol on keyboard). 
Type down "Setup for com0com," hit enter.

A command-prompt-style window shall appear.

Enter in "install Portname=COM10 Portname=COM11"
Enter in "quit"

Now you may run the relay, per its README,
included in "tcp-serial-server and support files.zip"